<?php

$username = 'root';
$password = '';
$database = 'dbpariwisata';
$host = 'localhost';

$db = mysqli_connect($host, $username, $password, $database);