<?php
include 'template/header.php';
include 'template/leftside.php';
?>

  <?php
  include 'template/footer.php';
  ?>